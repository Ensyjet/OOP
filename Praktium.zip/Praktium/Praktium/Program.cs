﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praktium
{
    class Program
    {
        static void Main(string[] args)
        {
            double x, y;
            Console.WriteLine("Введите х:");
            x=Convert.ToDouble(Console.ReadLine());
            y = 1 / (Math.Sqrt(x) + Math.Sqrt(2));
            Console.WriteLine("f(x)=" + y);
            Console.WriteLine("Нажмите любую кнопку, чтобы завершить программу");
            Console.ReadKey();
        }
    }
}
