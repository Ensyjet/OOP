﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praktium2
{
    class Program
    {
        static void Main(string[] args)
        {
            double x, y,f;
            const double r = 1;
            Console.WriteLine("Введите х:");
            x = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Введите y:");
            y = Convert.ToDouble(Console.ReadLine());
            f = Math.Pow(x, 2) + Math.Pow(y, 2);
            if((x>=-1&&x<0)&&(y< 0 && x >= -1))
            {
                Console.WriteLine("Точка входит в 3-ую четверть");
            }
            else if(f<Math.Pow(r,2)&&(x>0&&x<1)&&(y > 0 && y < 1))
            {
                Console.WriteLine("Точка входит в 1-ую четверть");
            }
            else
                Console.WriteLine("Точка не входит в график");
            Console.WriteLine("Нажмите любую кнопку, чтобы завершить программу");
            Console.ReadKey();
        }
    }
}
