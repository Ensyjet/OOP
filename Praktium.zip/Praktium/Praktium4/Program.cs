﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praktium4
{
    class Program
    {
        static void Main(string[] args)
        {
            
            double z,y;
            Console.WriteLine("Введите z:");
            z = Convert.ToDouble(Console.ReadLine());
            y = ComplexY(z);
            Console.WriteLine("y(z)=" + y);
            Console.WriteLine("Нажмите любую кнопку, чтобы завершить программу");
            Console.ReadKey();
        }

     static double ComplexY (double z)
        {
            return (2*z+ (Math.Exp(5)*(1+z)));
        }
    }
}
