﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praktium3_while_
{
    class Program
    {
        static void Main(string[] args)
        {
            int n,i=1;
            double a, sum = 0;
            Console.WriteLine("Введите количество элементов:");
            n = Convert.ToInt32(Console.ReadLine());
            while(i <= n)
            {
                a = Math.Pow(-1, i) * ((i + 1) / (Math.Pow(i, 3) + 2));
                sum = sum + a;
                i++;
            }
            Console.WriteLine("A(i)=" + sum);
            Console.WriteLine("Нажмите любую кнопку, чтобы завершить программу");
            Console.ReadKey();
        }
    }
}
